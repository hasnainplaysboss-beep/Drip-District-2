import { NextResponse } from "next/server";
export async function POST(){const res=NextResponse.json({ok:true});res.cookies.set("dd_admin","",{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:0});return res;}
